<div align="center">

# AEX BOT WhatsApp

</div>

### Install

```bash
> git clone https://github.com/ibnusyawall/aex-bot.git
> cd aex-bot
> npm i
> npm start
```

``Note : runing at port 5000``

#### Usage
<pre>
After scan barcode whatsapp, you can start message with following command : !menu for showing menu/command
</pre>


#### Changelog:
> ☑️ Fixing Other BUG 
>
> ☑️ Add Quotes Maker with commmand `!quotesmaker <size> <colorFont> <quotes>`
>
> ☑️ Delete trash file
> 
> ☑️ Add Any Fiture
>

#### Menu
<pre>
    -- AEX BOT WHATSAPP

    Group Command:

      !setName <optional> Ubah Nama Group
      !setDesc <optional> Ubah Deskripsi Group
      !demote <@tagmember> Demote Admin
      !promote <@tagmember> Promote Member
      !kick <@tagmember> Kick Member
      !kickall Kick all members
      !kickme Kick bot from group
      !add <number> Invite Member
      !owner Melihat Siapa Owner Group
      !getall Tag all members group

    Other Command:

      !quotes Auto Quotes
      !quotesmaker <size> <colorFont> <quotes> Quotes Maker
      !toxic Auto Toxic 

      !igdl <linkIG> IG Auto Downloader
      !ytmp3 <linkYT> Youtube MP3 Downloader
      !ytmp4 <linkYT> Youtube MP4 Downloader
      !qr <optional> QR Code Maker
      !tts [en/id] <optional> Text To Speech
      !js <namaKota> Cek Jadwal Sholat
      !wiki <query> Search on Wikipedia

      !sial <ttl> Cek hari sial kamu berdasarkan tanggal lahir
      !jodoh <nama1>&<nama2> Cek apakah dia cocok dengan kamu?
      !artinama <nama> Cek arti dari nama tersebut
      !sifat <nama> <ttl> Cek sifat berdasarkan nama dan tanggal lahir

      !jnt <koderesi/waybill> Melacak kode resi J&T
      !lex <koderesi/waybill> Melacak kode resi Lex
      !lion <koderesi/waybill> Melacak kode resi Lion
      !pos <koderesi/waybill> Melacak kode resi POS
      !tiki <koderesi/waybill> Melacak kode resi TiKi
      !sicepat <koderesi/waybill> Melacak kode resi Sicepat
      !anteraja <koderesi/waybill> Melacak kode resi AnterAja

      !randomnime Merandom gambar segar animek
      !randomhentai Merandom gambar segar hentai

      !botjoin <linkGroup> Undang Bot Ke Group Kalian

</pre>

found bug? or other problem? Pliese submit issues!

Open donation, contact me on WhatsApp: +6282299265151
