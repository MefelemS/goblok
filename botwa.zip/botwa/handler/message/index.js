module.exports = {
    MessageHandler: require('./MessageHandler')
}
